#include <iostream>

using namespace std;

int main()
{
  cout << "HellO WorlD!" << endl;
  return 0;
}
