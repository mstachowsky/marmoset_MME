#include <iostream>

using namespace std;

int main()
{
  cout << "This is the wrong text." << endl;
  return 0;
}
